
var inputs=document.querySelectorAll('.mortgage_input');
var inputs_num=document.querySelectorAll('.support_input_mort');
var text_mort=document.querySelector('.mortgage_summ span');
var summ_of_mortgage=document.querySelector('.summ_of_mortgage');
var progresses=document.querySelectorAll('.progress_check_mort');

var first_opt=document.querySelector('.first_first');
var second_opt=document.querySelector('.first_second');
var third_opt=document.querySelector('.first_third');

var button_minus_1=document.querySelector('.button_minus_mort');
var button_plus_1=document.querySelector('.button_plus_mort');

var mortgage_count=function(){
        
        inputs_num[0].value=inputs[0].value;
        inputs_num[1].value=inputs[1].value;
        inputs_num[2].value=inputs[2].value;
    
    if(inputs_num[2].value==30){
    button_plus_1.setAttribute('disabled','disabled');
}
else{
    button_plus_1.removeAttribute('disabled','disabled');
};

if(inputs_num[2].value==3){
    button_minus_1.setAttribute('disabled','disabled');
}
else{
    button_minus_1.removeAttribute('disabled','disabled');
};
        
        let number0=inputs_num[0].value;
        let number1=inputs_num[1].value;
        let number2=inputs_num[2].value;
        
        progresses[1].setAttribute('max',inputs[0].value);
        progresses[1].setAttribute('min',Math.floor(inputs[0].value/6));
        
        progresses[0].value=inputs_num[0].value-((inputs[0].getAttribute('max')-inputs_num[0].value)/180);
        
        progresses[1].value=inputs_num[1].value-((inputs[1].getAttribute('max')-inputs_num[1].value)/6);
        
        progresses[2].value=inputs_num[2].value-((inputs[2].getAttribute('max')-inputs_num[2].value)/12.4);
        
        let difference=number0-number1;
        let count_for_text=Math.ceil((difference)/(number2*12));
        if(difference<600000){
        $('.mort_right_lessmin').show(1);
        $('.mortgage_summ').hide(1);
        }
        else{
        $('.mort_right_lessmin').hide(1);
        $('.mortgage_summ').show(1);
        text_mort.textContent=count_for_text + ' ₽';
        };
        summ_of_mortgage.textContent=number0+' ₽';
        
        //values of second input(max/min)
        
        inputs[1].setAttribute('max',inputs[0].value);
        inputs[1].setAttribute('min',Math.floor(inputs[0].value/6));
        
        if(inputs[0].value.length>6){
            third_opt.setAttribute('label',Math.floor(inputs[0].value/100000)/10+' млн');
        }
        else{
            third_opt.setAttribute('label',Math.floor(inputs[0].value/100)/10+' тыс');
        };
        
        if((Math.floor(inputs[0].value/2).toString().length)>6){
            second_opt.setAttribute('label',Math.floor(inputs[0].value/200000)/10+' млн');
        }
        else{
            second_opt.setAttribute('label',Math.floor(inputs[0].value/200)/10+' тыс');
        };
        
        if((Math.floor(inputs[0].value/6).toString().length)>6){
            first_opt.setAttribute('label',Math.floor(inputs[0].value/600000)/10+' млн');
        }
        else{
            first_opt.setAttribute('label',Math.floor(inputs[0].value/600)/10+' тыс');
        };
        
        first_opt.value=Math.floor(inputs[0].value/6);
        second_opt.value=Math.floor(inputs[0].value/2);
        third_opt.value=Math.floor(inputs[0].value);
        //values of second input(max/min):end
        
        
        
    };

for(let i=0;i<3;++i){
    inputs[i].addEventListener('input',mortgage_count);
    inputs[i].addEventListener('change',mortgage_count);
    inputs_num[i].addEventListener('input',mortgage_count);
    inputs_num[i].addEventListener('change',mortgage_count);
    
};



button_minus_1.addEventListener('click', function(){
    
    inputs[2].value-=1;
    inputs_num[2].value-=1;
    
    mortgage_count();
    
    if(inputs[2].value==3){
    button_minus_1.setAttribute('disabled','disabled');
}
else{
    button_minus_1.removeAttribute('disabled','disabled');
};
if(inputs[2].value==30){
    button_plus_1.setAttribute('disabled','disabled');
}
else{
    button_plus_1.removeAttribute('disabled','disabled');
};

});




button_plus_1.addEventListener('click', function(){
 
    inputs[2].value=+inputs[2].value+1;
    inputs_num[2].value=+inputs_num[2].value+1;
    
    mortgage_count();
    
    if(inputs[2].value==30){
    button_plus_1.setAttribute('disabled','disabled');
}
else{
    button_plus_1.removeAttribute('disabled','disabled');
};

if(inputs[2].value==3){
    button_minus_1.setAttribute('disabled','disabled');
}
else{
    button_minus_1.removeAttribute('disabled','disabled');
};
});