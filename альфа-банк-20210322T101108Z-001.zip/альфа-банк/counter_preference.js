var rub=document.querySelector('.rub');
var dollar=document.querySelector('.dollar');
var eu=document.querySelector('.eu');
var all=document.querySelector('.to_all');
var premium=document.querySelector('.to_premium');

var currency=document.querySelector('.currency');
var buttons_up=document.querySelectorAll('.pref_button_left');
var difference=document.querySelector('.difference');
var buttons_bot=document.querySelectorAll('.pref_button_left_sec');

for(let button of buttons_up){
    button.addEventListener('click',()=>{
        let active=currency.querySelector('.pref_buttons_active');
       
       active.classList.remove('pref_buttons_active');
        button.classList.add('pref_buttons_active');
    });
};

for(let button_1 of buttons_bot){
    button_1.addEventListener('click',()=>{
        let active_1=difference.querySelector('.pref_buttons_active');
       
       active_1.classList.remove('pref_buttons_active');
        button_1.classList.add('pref_buttons_active');
    });
};

//$('ul').html('<li>молоко 500 мл литр</li><li>яйца 3 шт.</li><li>мука  200 гр.</li>');
rub.addEventListener('click',()=>{
    
    
    $('.preference_right_eur').hide(1);
    $('.preference_right_ruusd').show(1);
    $('.pref_right_pdfeur').show(1);
    $('.difference').show(1);
    $('.heading_usd1').html('');
    $('.heading_usd2').html('');
    $('#pref_right_span').html('В первые 2 месяца <sup>*</sup>');
    
    $('.usd1').html('');
    $('#b1').html('6%');
    
    $('.usd2').html('');
    $('#b2').html('4%');
    
    $('.usd3').html('');
    $('#b3').html('4%');
    
    $('.usd4').html('');
    $('#b4').html('4%');
    
    if(premium.classList.contains('pref_buttons_active'))
        
    {premium.click();}
    
    else
        
    {all.click();};
    
});


dollar.addEventListener('click',()=>{
    $('.preference_right_eur').hide(1);
    $('.preference_right_ruusd').show(1);
    $('.pref_right_pdfeur').show(1);
    $('.difference').show(1);
    
    $('#pref_right_span').html('В первые 2 месяца');
    
    
    $('.usd1').html('');
    $('#b1').html('0,1%');
    
    $('.usd2').html('');
    $('#b2').html('0,1%');
    
    $('.usd3').html('');
    $('#b3').html('0,1%');
    
    $('.usd4').html('');
    $('#b4').html('0,1%');
    
    if(premium.classList.contains('pref_buttons_active'))
        
    {premium.click();}
    
    else
        
    {all.click();};
    
});

eu.addEventListener('click',()=>{
    $('.preference_right_eur').show(1);
    $('.preference_right_ruusd').hide(1);
    $('.pref_right_pdfeur').hide(1);
    $('.difference').hide(1);
    
});


all.addEventListener('click',()=>{
    
    if(rub.classList.contains('pref_buttons_active')){
        $('#b4').html('4%');
        
        
    }
    else if(dollar.classList.contains('pref_buttons_active')){
       $('.heading_usd1').html('');
    $('.heading_usd2').html('');
        
    $('.usd1').html('');
    $('#b1').html('0,1%');
    
    $('.usd2').html('');
    $('#b2').html('0,1%');
    
    $('.usd3').html('');
    $('#b3').html('0,1%');
    
    $('.usd4').html('');
    $('#b4').html('0,1%');
        
    };
    
});

premium.addEventListener('click',()=>{
    
    if(rub.classList.contains('pref_buttons_active')){
        $('#b4').html('4,25%');
        
    }
    else if(dollar.classList.contains('pref_buttons_active')){
        
    $('.heading_usd1').html('До 15 000 $');
    $('.heading_usd2').html('От 15 000 $');
        
    $('.usd1').html('0,1%');
    $('#b1').html('0,1%');
    
    $('.usd2').html('0,2%');
    $('#b2').html('0,1%');
    
    $('.usd3').html('0,3%');
    $('#b3').html('0,1%');
    
    $('.usd4').html('0,4%');
    $('#b4').html('0,1%');
        
    };
    
});