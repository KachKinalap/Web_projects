/*выезжающее меню*/

var clear=0;

$('#stretch_nav_1').click(function(){
    $('.main_nav').css('width', '820px');
    $('#small_search_nav_1').hide(100);
    $('#stretch_nav_1').attr('style', 'transform:scale(-1,1) translate(-380px,0)');
    $('.buttons_header').hide(100);
    
});

function header(){
   $('.main_nav').attr('style', 'width:420px;');
   $('#stretch_nav_1').css('transform', '');
   $('#stretch_nav_1').css('margin-left', '-20');
   $('#small_search_nav_1').delay(300).show(100);
   $('.buttons_header').delay(300).show(100);
    
};

$('.header_default').hover(function(){
    
    clearTimeout(clear);
});

$('.header_default').mouseleave(
    function(){
        clear=setTimeout(header, 1000);
    });

/*выезжающее меню:конец*/
/*поиск*/
$('.small_search_nav').click(function(evt){
    evt.preventDefault();
   $('.input_search_img').show(150); 
   $('.search_input').css('box-shadow','0 0 0 1000px rgba(0, 0, 0,.5)').show(150); 
   $('#body').css('overflow','hidden');
   
});

$(document).mouseup(function (e){ // событие клика по веб-документу
		let div = $(".search_input"); // тут указываем ID элемента
		if (!div.is(e.target) // если клик был не по нашему блоку
		    && div.has(e.target).length === 0) { // и не по его дочерним элементам
			$('.search_input').css('box-shadow','0 0 0 1000px rgba(0, 0, 0, 0)').hide(150); 
            $('.input_search_img').hide(150); 
   
		}
	});
/*поиск:конец*/
/*онлайн заявки*/
$('.online_invite').click(function(){
   $('.unvisible_menu_header').show(100); 
});

$(document).mouseup(function (i){ // событие клика по веб-документу
		let div = $(".unvisible_menu_header"); // тут указываем ID элемента
		if (!div.is(i.target) // если клик был не по нашему блоку
		    && div.has(i.target).length === 0) { // и не по его дочерним элементам
			$('.unvisible_menu_header').hide(100); 
		}
	});
/*онлайн заявки:конец*/
/*нижняя панель(4 варианта)*/

var item_panel=document.querySelectorAll('.choose');

for(let item of item_panel){
    $(item).click(function(){
        console.log(item);
        let erase=document.querySelector('.choose_choosed');
        erase.classList.remove('choose_choosed');
        item.classList.add('choose_choosed');
    });
};
/*нижняя панель(4 варианта):конец*/
/*картинки и содержимое хэдера*/
    $('.choose_uh_one').click(function(){
       $('.choose').removeClass('uh_gradient');
        $('.underhead_first').show(1);
        $('.underhead_second').hide(1);
        $('.underhead_third').hide(1);
        $('.underhead_fourth').hide(1);
            $('.container_header').css('background-color','#EAECF0');
            $('#logo_white').hide(1);
            $('#logo_red').show(1);
            $('.main_nav_point').css('color','#7a8592');
            $('.side_nav_point').css('color','#0B1F35');
            $('#stretch_nav_1').show(1);
            $('#stretch_nav_2').hide(1);
            $('#small_search_nav_1').show(1);
            $('#small_search_nav_2').hide(1);
            $('.online_invite_red').show(1);
            $('.online_invite_white').hide(1);
});

$('.choose_uh_two, .choose_uh_three, .choose_uh_four').click(function(){
    $('.container_header').css('background-color','#0A1017');
    $('.choose').addClass('uh_gradient');
            $('#logo_white').show(1);
            $('#logo_red').hide(1);
            $('.main_nav_point').css('color','white');
            $('.side_nav_point').css('color','white');
            $('#stretch_nav_1').hide(1);
            $('#stretch_nav_2').show(1);
            $('#small_search_nav_1').hide(1);
            $('#small_search_nav_2').show(1);
            $('.online_invite_red').hide(1);
            $('.online_invite_white').show(1);
});


function choose_uh_two(){
    $('.underhead_first').hide(1);
        $('.underhead_second').show(1);
        $('.underhead_third').hide(1);
        $('.underhead_fourth').hide(1);
};

function choose_uh_three(){
     $('.underhead_first').hide(1);
        $('.underhead_second').hide(1);
        $('.underhead_third').show(1);
        $('.underhead_fourth').hide(1);
};

function choose_uh_four(){
     $('.underhead_first').hide(1);
        $('.underhead_second').hide(1);
        $('.underhead_third').hide(1);
        $('.underhead_fourth').show(1);
};

var choose_two = document.querySelector('.choose_uh_two');
var choose_three = document.querySelector('.choose_uh_three');
var choose_four = document.querySelector('.choose_uh_four');

choose_two.addEventListener('click',choose_uh_two);
choose_three.addEventListener('click',choose_uh_three);
choose_four.addEventListener('click',choose_uh_four);

/*картинки и содержимое хэдера:конец*/


