//когда жмём на один из вариков
var item_panel=document.querySelectorAll('.calculate_nav_item');
var input_for_credit=document.getElementById('input_for_credit');
var credit=document.getElementById('credit');
var item_years=document.querySelectorAll('.credit_years_button');
var button_minus=document.querySelector('.math_minus');
var button_plus=document.querySelector('.math_plus');
var progress=document.getElementById('progress_check');

for(let item of item_panel){
    $(item).click(function(){
        let erase=document.querySelector('.calculate_nav_choosed');
        erase.classList.remove('calculate_nav_choosed');
        item.classList.add('calculate_nav_choosed');
    });
};

$('#calculate_nav_item_f').click(function(){
       $('.flex_credit').removeClass('hidden');
        $('.flex_mortgage').addClass('hidden');
        $('.flex_preference').addClass('hidden');
});
$('#calculate_nav_item_s').click(function(){
       $('.flex_credit').addClass('hidden');
        $('.flex_mortgage').removeClass('hidden');
        $('.flex_preference').addClass('hidden');
});
$('#calculate_nav_item_t').click(function(){
       $('.flex_credit').addClass('hidden');
        $('.flex_mortgage').addClass('hidden');
        $('.flex_preference').removeClass('hidden');
});

//когда жмём на один из вариков:конец

//кредит наличными
//хочу сделать годы активными


for(let itemm of item_years){
    $(itemm).click(function(){
        
        
        itemm.addEventListener('click',credit_function);
        itemm.addEventListener('click',screens_credit);
        let erase=document.querySelector('.credit_years_buttons_active');
        erase.classList.remove('credit_years_buttons_active');
        itemm.classList.add('credit_years_buttons_active');
        
    if(item_years[4].classList.contains('credit_years_buttons_active')){
           button_plus.setAttribute("disabled", "disabled"); 
           button_minus.removeAttribute("disabled", "disabled");
        }
        else{button_plus.removeAttribute("disabled", "disabled");};
        
        
        if(item_years[0].classList.contains('credit_years_buttons_active')){
           button_minus.setAttribute("disabled", "disabled"); 
           button_plus.removeAttribute("disabled", "disabled");
            }
        else{button_minus.removeAttribute("disabled", "disabled"); };
    });
};
//хочу сделать годы активными:конец



var credit_function=function(){
    progress.value=+credit.value+39000;
    let koef_year=0;
    
    let curr_year=document.querySelector('.credit_years_buttons_active');
    
    if(curr_year.classList.contains('credit_years_button_1')){
        koef_year=1;
    }
    else if(curr_year.classList.contains('credit_years_button_2')){
        koef_year=0.5;
    }
    else if(curr_year.classList.contains('credit_years_button_3')){
        koef_year=0.33;
    }
    else if(curr_year.classList.contains('credit_years_button_4')){
        koef_year=0.25;
    }
    else if(curr_year.classList.contains('credit_years_button_5')){
        koef_year=0.2;
    }
        else{koef_year=1;};
    
    let curr_c=$('#credit').val();
    input_for_credit.value=curr_c;
    let span_for_credit=document.querySelector('.span_for_credit');
    
    span_for_credit.innerHTML=Math.floor((curr_c/100*9+curr_c/1000)*koef_year)+' ₽';
    let percentss_for_credit=document.querySelector('.percentss_for_credit');
    if(curr_c>300000 && curr_c<1500000){
        
         percentss_for_credit.innerHTML='6,7'+' %';            
                     }
    else if(curr_c>=1500000 && curr_c<=5000000){
        
        percentss_for_credit.innerHTML='5,7'+' %';
    }
    else{percentss_for_credit.innerHTML='7,7'+' %';};
};

credit.addEventListener('input',credit_function);

//var choose_two = document.querySelector('.choose_uh_two');
//choose_two.addEventListener('click',choose_uh_two);

var screens_credit=function(){
let curr=$('#input_for_credit').val();
    if(curr==''){
        $('.promote_less100k_notsumm').removeClass('hidden');
        $('.promote_less100k_summ').addClass('hidden');
        $('.promote_summ').addClass('hidden');
        $('.promote_summ_oversize').addClass('hidden');
    }
    else if(curr<100000 && curr!=''){
        $('.promote_less100k_notsumm').addClass('hidden');
        $('.promote_less100k_summ').removeClass('hidden');
        $('.promote_summ').addClass('hidden');
        $('.promote_summ_oversize').addClass('hidden');
    }
    else if(curr>5000000){
        $('.promote_less100k_notsumm').addClass('hidden');
        $('.promote_less100k_summ').addClass('hidden');
        $('.promote_summ').addClass('hidden');
        $('.promote_summ_oversize').removeClass('hidden');
        
    }
    else{
        $('.promote_less100k_notsumm').addClass('hidden');
        $('.promote_less100k_summ').addClass('hidden');
        $('.promote_summ').removeClass('hidden');
        $('.promote_summ_oversize').addClass('hidden');
    };
};
credit.addEventListener('input',screens_credit);
input_for_credit.addEventListener('input',screens_credit);
input_for_credit.addEventListener('change',screens_credit);


//теперь активируем кнопочки


button_minus.addEventListener('click', function(event) {
  event.preventDefault();
    button_plus.removeAttribute("disabled", "disabled");
    for(let i=0;i<5;i++){
        if(item_years[i].classList.contains('credit_years_buttons_active')){
           item_years[i-1].click();
            break;
        };
    };
    
    if(item_years[0].classList.contains('credit_years_buttons_active')){
        button_minus.setAttribute("disabled", "disabled");
    };
    
});


button_plus.addEventListener('click', function(event) {
    
  event.preventDefault();
    button_minus.removeAttribute("disabled", "disabled");
    for(let i=0;i<5;i++){
        if(item_years[i].classList.contains('credit_years_buttons_active')){
           item_years[i+1].click();
            break;
        };
    };
    if(item_years[4].classList.contains('credit_years_buttons_active')){
        button_plus.setAttribute("disabled", "disabled");
    };
    
});
//теперь активируем кнопочки:конец
//кредит наличными:конец


