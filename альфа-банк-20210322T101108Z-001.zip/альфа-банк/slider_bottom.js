
    'use strict';
    var multiItemSlider1 = (function () {
      return function (selector1, config1) {
        var
          _mainElement1 = document.querySelector(selector1), // основный элемент блока
          _sliderWrapper1 = _mainElement1.querySelector('.obertka_for_obertka'), // обертка для .slider-item
            _sliderWrapper2 = _mainElement1.querySelector('.obertka_for_slides'),// перемещающийся элемент
          _sliderItems1 = _mainElement1.querySelectorAll('.serv_slider_item'), // элементы (.slider-item)
          _sliderControls1 = _mainElement1.querySelectorAll('.slider_serv_nav'), // элементы управления
          _sliderControlLeft1 = _mainElement1.querySelector('.slider_serv_nav_left'), // кнопка "LEFT"
          _sliderControlRight1 = _mainElement1.querySelector('.slider_serv_nav_right'), // кнопка "RIGHT"
          _wrapperWidth1 = parseFloat(getComputedStyle(_sliderWrapper1).width), // ширина обёртки
          _itemWidth1 = parseFloat(getComputedStyle(_sliderItems1[0]).width), // ширина одного элемента    
          _positionLeftItem1 = 0, // позиция левого активного элемента
          _transform1 = 0, // значение транфсофрмации .slider_wrapper
          _step1 = _itemWidth1 / _wrapperWidth1 * 100, // величина шага (для трансформации)
          _items1 = []; // массив элементов
        
        // наполнение массива _items
        _sliderItems1.forEach(function (item1, index1) {
          _items1.push({ item1: item1, position1: index1, transform1: 0 });
        });

        var position1 = {
          getMin1: 0,
          getMax1: _items1.length - 1,
        }

        var _transformItem1 = function (direction1) {
          if (direction1 === 'right') {
            if ((_positionLeftItem1 + _wrapperWidth1 / _itemWidth1 - 1) >= position1.getMax1) {
              return;
            }
            if (!_sliderControlLeft1.classList.contains('slider__control_show1')) {
              _sliderControlLeft1.classList.add('slider__control_show1');
            }
            if (_sliderControlRight1.classList.contains('slider__control_show1') && (_positionLeftItem1 + _wrapperWidth1 / _itemWidth1) >= position1.getMax1) {
              _sliderControlRight1.classList.remove('slider__control_show1');
            }
            _positionLeftItem1++;
            _transform1 -= _step1;
          }
          if (direction1 === 'left') {
            if (_positionLeftItem1 <= position1.getMin1) {
              return;
            }
            if (!_sliderControlRight1.classList.contains('slider__control_show1')) {
              _sliderControlRight1.classList.add('slider__control_show1');
            }
            if (_sliderControlLeft1.classList.contains('slider__control_show1') && _positionLeftItem1 - 1 <= position1.getMin1) {
              _sliderControlLeft1.classList.remove('slider__control_show1');
            }
            _positionLeftItem1--;
            _transform1 += _step1;
          }
          _sliderWrapper2.style.transform = 'translateX(' + (_transform1/2) + '%)';
        }

        // обработчик события click для кнопок "назад" и "вперед"
        var _controlClick1 = function (e1) {
          if (e1.target.classList.contains('slider_serv_nav')) {
            e1.preventDefault();
            var direction1 = e1.target.classList.contains('slider_serv_nav_right') ? 'right' : 'left';
            _transformItem1(direction1);
            
          }
        };

        var _setUpListeners1 = function () {
          // добавление к кнопкам "назад" и "вперед" обрботчика _controlClick для событя click
          _sliderControls1.forEach(function (item1) {
            item1.addEventListener('click', _controlClick1);
          });
        }

        // инициализация
        _setUpListeners1();

        return {
          right: function () { // метод right
            _transformItem1('right');
          },
          left: function () { // метод left
            _transformItem1('left');
          }
        }

      }
    }());

    var slider1 = multiItemSlider1('.services_slider')

 